import sys
sys.path.insert(0, './lib')  # noqa
